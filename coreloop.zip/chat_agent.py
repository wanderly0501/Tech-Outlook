"""
chat_agent.py

Always-on interactive agent. User talks to it; it answers from
the local knowledge base, optionally doing web search for deep dives.

Write permissions: conversations table, preferences.md
Read permissions:  articles.db (all tables), all memory/*.md files
"""

import json
from datetime import datetime
from core.agent_loop import run_agent_loop, build_system_prompt

# ── Memory files injected into every system prompt ───────────────────────────
MEMORY_PATHS = [
    "memory/session.md",
    "memory/preferences.md",
    "memory/top_of_mind.md",
]

BASE_SYSTEM_PROMPT = """
You are a knowledgeable tech news assistant with a continuously updated local
knowledge base of articles from The Verge.

Your personality:
- Conversational and direct — no fluff
- Proactively surface interesting things from your top_of_mind memory
- When you don't know something, say so and offer to search

Your capabilities:
- Answer questions about tech trends and news from your knowledge base
- Do deeper web searches when the user wants to explore a concept
- Update your understanding of user preferences as the conversation reveals them

Rules:
- Prefer search_kb over web_search unless the user explicitly wants fresh web results
- Always cite article titles and URLs when referencing stored knowledge
- After each conversation, summarize key user interests discovered (for preferences.md)
""".strip()

# ── Tool definitions (Anthropic JSON schema) ──────────────────────────────────
TOOLS = [
    {
        "name": "search_kb",
        "description": "Search the local knowledge base of stored articles.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search terms"},
                "mode": {
                    "type": "string",
                    "enum": ["text", "topic", "date"],
                    "description": "text=full-text search, topic=filter by topic, date=filter by date range"
                },
                "topic": {"type": "string", "description": "Topic filter (mode=topic)"},
                "date_from": {"type": "string", "description": "ISO date, e.g. 2026-07-01"},
                "date_to": {"type": "string", "description": "ISO date, e.g. 2026-07-05"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["query"],
        },
    },
    {
        "name": "web_search",
        "description": "Search the web for current information beyond the knowledge base.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 5},
            },
            "required": ["query"],
        },
    },
    {
        "name": "update_memory",
        "description": "Update a memory file. Chat agent may only update preferences.",
        "input_schema": {
            "type": "object",
            "properties": {
                "file": {
                    "type": "string",
                    "enum": ["preferences"],   # chat agent: preferences only
                    "description": "Which memory file to update"
                },
                "content": {"type": "string", "description": "Full new content"},
                "mode": {
                    "type": "string",
                    "enum": ["overwrite", "append"],
                    "default": "overwrite"
                },
            },
            "required": ["file", "content"],
        },
    },
]

# ── Tool dispatcher ───────────────────────────────────────────────────────────
def dispatch(tool_name: str, tool_input: dict) -> dict:
    """Route tool calls to the appropriate function."""
    from tools.search_kb import search_kb
    from tools.web_search import web_search
    from tools.update_memory import update_memory

    handlers = {
        "search_kb": search_kb,
        "web_search": web_search,
        "update_memory": update_memory,
    }

    if tool_name not in handlers:
        return {"error": f"Unknown tool: {tool_name}"}

    return handlers[tool_name](**tool_input)


# ── Conversation persistence ──────────────────────────────────────────────────
def save_conversation(messages: list[dict], summary: str):
    """Append this conversation to the conversations table in articles.db."""
    import sqlite3, json
    conn = sqlite3.connect("knowledge/articles.db")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at TEXT,
            summary TEXT,
            messages TEXT
        )
    """)
    # Serialize only serializable parts (strip SDK objects)
    safe_messages = []
    for m in messages:
        content = m["content"]
        if isinstance(content, str):
            safe_messages.append({"role": m["role"], "content": content})
        elif isinstance(content, list):
            # Keep only text blocks for storage
            text = " ".join(
                b.text if hasattr(b, "text") else b.get("content", "")
                for b in content
                if (hasattr(b, "type") and b.type == "text")
                or (isinstance(b, dict) and b.get("type") == "tool_result")
            )
            safe_messages.append({"role": m["role"], "content": text})

    conn.execute(
        "INSERT INTO conversations (started_at, summary, messages) VALUES (?, ?, ?)",
        (datetime.now().isoformat(), summary, json.dumps(safe_messages))
    )
    conn.commit()
    conn.close()


# ── Main chat loop ────────────────────────────────────────────────────────────
def main():
    print("Tech News Agent — type 'quit' to exit\n")

    system_prompt = build_system_prompt(BASE_SYSTEM_PROMPT, MEMORY_PATHS)
    messages = []

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if user_input.lower() in ("quit", "exit", "q"):
            break
        if not user_input:
            continue

        messages.append({"role": "user", "content": user_input})

        print("Agent: ", end="", flush=True)

        response = run_agent_loop(
            messages=messages,
            system_prompt=system_prompt,
            tools=TOOLS,
            dispatch=dispatch,
            on_text=lambda t: print(t, end="", flush=True),
        )

        print()  # newline after streaming text

    # ── End of session: persist conversation ─────────────────────────────────
    if messages:
        save_conversation(messages, summary="Session ended " + datetime.now().isoformat())
        print("[session saved]")


if __name__ == "__main__":
    main()
