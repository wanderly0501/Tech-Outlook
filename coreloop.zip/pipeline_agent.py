"""
pipeline_agent.py

Scheduled autonomous agent. Runs daily via scheduler.py.
No user interaction — crawls, processes, stores, reports.

Write permissions: articles.db (articles, reports), all memory/*.md files
Read permissions:  everything
"""

from datetime import datetime
from core.agent_loop import run_agent_loop, build_system_prompt

# ── Memory files injected into system prompt ──────────────────────────────────
MEMORY_PATHS = [
    "memory/session.md",
    "memory/top_of_mind.md",
]

BASE_SYSTEM_PROMPT = """
You are an autonomous tech news pipeline agent. You run once daily.

Your job, in order:
1. Crawl The Verge for today's articles
2. Summarize and store each article in the knowledge base
3. Cluster articles into topics (AI, hardware, policy, etc.)
4. Update top_of_mind.md with the 5 most interesting findings
5. Write a daily HTML report with a topic pie chart and article highlights
6. Send the report to the user interface

Be concise and systematic. Do not ask questions — make decisions autonomously.
After each step, call the next tool immediately without commentary.
If a step fails, log the error and continue to the next step.
""".strip()

# ── Tool definitions ──────────────────────────────────────────────────────────
TOOLS = [
    {
        "name": "crawl",
        "description": "Fetch and parse articles from a tech website for a given date.",
        "input_schema": {
            "type": "object",
            "properties": {
                "site": {
                    "type": "string",
                    "enum": ["theverge"],
                },
                "date": {
                    "type": "string",
                    "description": "ISO date string, e.g. 2026-07-05"
                },
            },
            "required": ["site", "date"],
        },
    },
    {
        "name": "search_kb",
        "description": "Search articles already stored in the knowledge base.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "mode": {
                    "type": "string",
                    "enum": ["text", "topic", "date"],
                },
                "date_from": {"type": "string"},
                "date_to": {"type": "string"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["query"],
        },
    },
    {
        "name": "update_memory",
        "description": "Update a memory file. Pipeline agent controls all memory files.",
        "input_schema": {
            "type": "object",
            "properties": {
                "file": {
                    "type": "string",
                    "enum": ["session", "top_of_mind"],
                },
                "content": {"type": "string"},
                "mode": {
                    "type": "string",
                    "enum": ["overwrite", "append"],
                    "default": "overwrite"
                },
            },
            "required": ["file", "content"],
        },
    },
    {
        "name": "write_report",
        "description": "Write a daily or weekly HTML/MD report with optional charts.",
        "input_schema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Report body in markdown"},
                "format": {"type": "string", "enum": ["html", "md"], "default": "html"},
                "report_type": {"type": "string", "enum": ["daily", "weekly"], "default": "daily"},
                "date": {"type": "string", "description": "ISO date, defaults to today"},
                "charts": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "type": {"type": "string", "enum": ["pie", "bar", "timeline"]},
                            "title": {"type": "string"},
                            "data": {"type": "object", "description": "label→value pairs"},
                        },
                    },
                    "description": "Chart specs to embed in the report"
                },
            },
            "required": ["content"],
        },
    },
    {
        "name": "send",
        "description": "Send the report to the user interface and/or email.",
        "input_schema": {
            "type": "object",
            "properties": {
                "target": {"type": "string", "enum": ["interface", "email", "both"]},
                "report_path": {"type": "string"},
                "subject": {"type": "string"},
                "recipient": {"type": "string"},
            },
            "required": ["target", "report_path"],
        },
    },
]

# ── Tool dispatcher ───────────────────────────────────────────────────────────
def dispatch(tool_name: str, tool_input: dict) -> dict:
    from tools.crawler import crawl
    from tools.search_kb import search_kb
    from tools.update_memory import update_memory
    from tools.write_report import write_report
    from tools.send import send

    handlers = {
        "crawl": crawl,
        "search_kb": search_kb,
        "update_memory": update_memory,
        "write_report": write_report,
        "send": send,
    }

    if tool_name not in handlers:
        return {"error": f"Unknown tool: {tool_name}"}

    return handlers[tool_name](**tool_input)


# ── Entry point ───────────────────────────────────────────────────────────────
def run_pipeline(date: str | None = None):
    today = date or datetime.now().strftime("%Y-%m-%d")
    print(f"[pipeline] Starting run for {today}")

    system_prompt = build_system_prompt(BASE_SYSTEM_PROMPT, MEMORY_PATHS)

    # Kick off with a single trigger message — Claude drives the rest
    messages = [{
        "role": "user",
        "content": f"Run the full daily pipeline for {today}. Site: theverge."
    }]

    result = run_agent_loop(
        messages=messages,
        system_prompt=system_prompt,
        tools=TOOLS,
        dispatch=dispatch,
        on_text=lambda t: print(t, end="", flush=True),
    )

    print(f"\n[pipeline] Completed for {today}")
    return result


if __name__ == "__main__":
    run_pipeline()
